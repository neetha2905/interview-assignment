

Program will generate words with all possible combination of the characters from the entered numbers

To run the program, run the "Runner.java" from src.interviewassignment.runner package

Util package is created with below files
- CharaterMap.java -- converts and maps entered number with character for that number
- PrintCharacters.java  -- will print the combinational characters
- RunnerInput -- Reads the input and then prints

