package com.interviewassignment.runner;

import com.interviewassignment.util.RunnerInput;

public class runner {
	/**
	 * Reads input from user
	 * @param args
	 * @throws InterruptedException
	 * @author Neetha Tipparthi
	 */
	
	public static void main(String[] args) throws InterruptedException {
		
		RunnerInput.readUserInput();
		
	}

}
